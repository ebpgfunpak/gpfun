#!/bin/bash

# use: check_for_updates.sh [current_version]

echo
echo "Checking for updates..."
echo 
rm -f latest_gpfun_version
wget https://github.com/ebpgfunpak/gpfun/blob/main/version?raw=true -O latest_gpfun_version
read latest_version < latest_gpfun_version
rm -f latest_gpfun_version

if [ "$latest_version" == "" ]; then
    echo
    echo "Unable to connect to github.com to check for updates."
    echo
    exit
fi

if [ `python3 -c "print( $1 < $latest_version )"` == "True" ]; then
    echo
    echo
    echo
    echo "******************************************************************"
    echo " A new version of gpfun ($latest_version) is available.                             "
    echo " Click on the 'update' button in gpfun to install the new version."
    echo "******************************************************************"
    echo
    echo
fi









