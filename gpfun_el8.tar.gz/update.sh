#!/bin/bash

# Download and install the lastest update.

# use: update.sh installpath        
# this does not work with ubuntu linux

# installpath is normally /usr/local/bin/ebpg_funpak
# but maybe not, so it's passed from gpfun to here


tarfile="gpfun_el8.tar"


if [ `whoami` != "root" ]; then
    echo
    echo "You must be root to install an update."
    read -p "Would you like to become root now? y/n > " ans
    
    if [ "$ans" == "y" ] || [ "$ans" == "Y" ]; then
        echo
        su --command="$1/update.sh $1"
        exit
        echo
        if [ `whoami` != "root" ]; then
            echo
            echo "Sorry, logging in as root did not work. Please try again."
            echo
            exit
        fi
    else
        echo
        echo "Ok then, perhaps some other time."
        echo
        exit
    fi
fi
    
echo
echo "Downloading the update..."
echo

if [ -f $tarfile ]; then rm $tarfile ; fi

#wget https://github.com/ebpgfunpak/gpfun/blob/main/gpfun_el8.tar?raw=true -O gpfun_el8.tar

if [ ! -f $tarfile ]; then
    echo
    echo "ERROR: unable to download $tarfile"
    echo
    exit
fi

if [ `pwd` != $installpath ]; then
    mv $tarfile $installpath/
    cd $installpath
fi

echo
echo "we should be in the installation dir now"
echo
   
ls 
#install.sh















